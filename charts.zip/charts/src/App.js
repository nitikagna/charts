import './App.css';
import MyBarchart from './components/MyBarchart';

function App() {
  return (
    <div className="App">
      <div>
        <h1>Sales Dashboard</h1>
        <br/><br/><br/><br/>
        <MyBarchart />
      </div>
    </div>
  );
}

export default App;
