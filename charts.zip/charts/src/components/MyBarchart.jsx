// import React from 'react';
// import {
//   BarChart,
//   Bar,
//   XAxis,
//   YAxis,
//   Tooltip,
//   CartesianGrid,
//   Legend,
//   ResponsiveContainer,
// } from 'recharts';

// const MyBarchart = () => {
//   const data = [
//     { name: 'January', sales: 30 },
//     { name: 'February', sales: 45 },
//     { name: 'March', sales: 60 },
//     { name: 'April', sales: 20 },
//   ];

//   return (
//     <div style={{ width: '100%', height: 300 }}>
//       <ResponsiveContainer>
//         <BarChart data={data}>
//           <CartesianGrid strokeDasharray="3 3" />
//           <XAxis dataKey="name" />
//           <YAxis />
//           <Tooltip />
//           <Legend />
//           <Bar dataKey="sales" fill="#8884d8" />
//         </BarChart>
//       </ResponsiveContainer>
//     </div>
//   );
// };

// export default MyBarchart;



// import React from 'react';
// import {
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   ResponsiveContainer,
// } from 'recharts';

// const MyBarchart = () => {
//   const data = [
//     { month: 'January', sales: 30, profit: 20, expenses: 10 },
//     { month: 'February', sales: 45, profit: 30, expenses: 15 },
//     { month: 'March', sales: 60, profit: 40, expenses: 20 },
//     { month: 'April', sales: 80, profit: 50, expenses: 25 },
//     { month: 'May', sales: 95, profit: 65, expenses: 30 },
//     { month: 'June', sales: 120, profit: 85, expenses: 35 },
//   ];

//   return (
//     <div style={{ width: '100%', height: 300 }}>
//       <ResponsiveContainer>
//         <LineChart data={data}>
//           <CartesianGrid strokeDasharray="3 3" />
//           <XAxis dataKey="month" />
//           <YAxis />
//           <Tooltip />
//           <Legend />
          
//           {/* First Line: Sales */}
//           <Line type="monotone" dataKey="sales" stroke="#8884d8" />
          
//           {/* Second Line: Profit */}
//           <Line type="monotone" dataKey="profit" stroke="#82ca9d" />
          
//           {/* Third Line: Expenses */}
//           <Line type="monotone" dataKey="expenses" stroke="#ff7300" />
          
//         </LineChart>
//       </ResponsiveContainer>
//     </div>
//   );
// };

// export default MyBarchart;


import React from 'react';
import {
  PieChart,
  Pie,
  Tooltip,
  Cell,
  ResponsiveContainer,
} from 'recharts';

const MyBarchart = () => {
  const data = [
    { name: 'Product A', value: 400 },
    { name: 'Product B', value: 300 },
    { name: 'Product C', value: 300 },
    { name: 'Product D', value: 200 },
  ];

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

  return (
    <div style={{ width: '100%', height: 300 }}>
      <ResponsiveContainer>
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            nameKey="name"
            outerRadius={120}
            fill="#8884d8"
            label
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MyBarchart;

